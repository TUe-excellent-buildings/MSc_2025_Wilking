#ifndef BSO_GRAMMAR_SD_RULE_SET_CPP
#define BSO_GRAMMAR_SD_RULE_SET_CPP

namespace bso { namespace grammar { namespace rule_set { namespace sd_rule_set {

sd_rule_set::sd_rule_set()
{
	
} // ctor()

sd_rule_set::~sd_rule_set()
{
	
} // dtor()

} // namespace sd_rule_set
} // namespace rule_set
} // namespace grammar
} // namespace bso

#endif // BSO_GRAMMAR_SD_RULE_SET_CPP