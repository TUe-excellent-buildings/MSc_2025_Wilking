#ifndef BSO_GRAMMAR_BP_RULE_SET_CPP
#define BSO_GRAMMAR_BP_RULE_SET_CPP

namespace bso { namespace grammar { namespace rule_set { namespace bp_rule_set {

bp_rule_set::bp_rule_set()
{
	
} // ctor()

bp_rule_set::~bp_rule_set()
{
	
} // dtor()
	
} // namespace bp_rule_set
} // namespace rule_set
} // namespace grammar
} // namespace bso

#endif // BSO_GRAMMAR_BP_RULE_SET_CPP