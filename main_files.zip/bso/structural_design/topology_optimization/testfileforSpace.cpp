#ifndef SD_TOPOPT_TESTSPACE_SIMP_CPP
#define SD_TOPOPT_TESTSPACE_SIMP_CPP

namespace bso { namespace structural_design { namespace topology_optimization {

class TESTSPACE_SIMP;

namespace testspace_simp {
void ObjectiveAndSensitivity(
		 const std::map<component::geometry*, std::vector<element::element*>>& elePerComp,
		 double& c, const Eigen::VectorXd& x, Eigen::VectorXd& dc, Eigen::VectorXd& dv,
		 const double& penal);
void OptimalityCritUpdate(double l1, double l2, const double& xMove, 
		 const double& totalVolume, const double& f, Eigen::VectorXd& volume,
		 Eigen::VectorXd& x, Eigen::VectorXd& xNew, const Eigen::VectorXd& dv,
		 const Eigen::VectorXd& dc);

} // namespace testspace_simp
} // namespace topology_optimization


//START topopt function used in topopt main.cpp now
template <>
void sd_model::topologyOptimization<topology_optimization::TESTSPACE_SIMP>(
			const double& f, const double& penal, const double& xMove,
			const double& tolerance)
{
	std::cout << "Running TESTSPACE_SIMP: " << std::endl;

	using namespace topology_optimization::testspace_simp;
	std::ostream out(mTopOptStreamBuffer);
	//std::map vs std::vector from element
	std::map<component::geometry*, std::vector<element::element*>> fComp, bComp, tComp;
	double fVolume = 0, bVolume= 0, tVolume = 0, spaceVolume = 0, totVolume = 0; // initialised at 0, before each element volumes are added
	double cF, cB, cT; // sum of all the elements compliances (objective values)

	std::vector<std::pair<bso::spatial_design::conformal::cf_space, std::vector<component::geometry*>>> spaceComp;
	//allows to iterate over the spaces and get the components
	std::map<component::geometry*, std::vector<bso::spatial_design::conformal::cf_space>> compSpace;
	//allows to iterate over the components and get the spaces

	
	//std::map<std::vector<bso::spatial_design::conformal::cf_space>, std::map<component::geometry*, std::vector<element::element*>>> spaceComp3;
	std::vector<bso::spatial_design::conformal::cf_space> cfSpace;
	
	std::vector<element::element*> fEle, bEle, tEle;
	int count = 0;
	std::cout << "mGeometries.size(): " << mGeometries.size() << std::endl;
	for (auto& k : cfSpace) 
	{
		for (auto& i : mGeometries)
		{		
			if(i->isQuadrilateral())
 			{
 			std::cout << "\ni->getCfRectanglePtr() is rectangle: " << *(i->getCfRectanglePtr()) << std::endl;
 				for(const auto n: (i->getCfRectanglePtr())->cfSurfaces())
 				{
 					std::cout << "surface: " << *n << std::endl;
 					std::cout << "connected to the following space(s): " << std::endl;
 					for(const auto space: n->cfSpaces())
 					{
 						std::cout << "space: " << *space << std::endl;
 					}
 				}
 			}
			fEle.clear(); bEle.clear(); tEle.clear();
			for (auto& j : i->getElements())
			{
				if (!j->isActiveInCompliance()) continue;
				j->updateDensity(f,penal);
				if (j->isFlatShell())
				{
					fEle.push_back(j); //add flat shell to list of elements fEle. fEle is list of elements
					fVolume += j->getVolume();
				}
				else if (j->isBeam())
				{
					bEle.push_back(j);//add beam to list of elements bEle
					bVolume += j->getVolume();
				}
				else if (j->isTruss())
				{
					tEle.push_back(j); //add truss to list of elements tEle
					tVolume += j->getVolume();
				}
			}
			if (!fEle.empty()) fComp[i] = fEle;
			if (!bEle.empty()) bComp[i] = bEle;
			if (!tEle.empty()) tComp[i] = tEle;
		}
		if (!fComp.empty()) spaceComp3[k] = fComp;
	}
}

	std::cout << "\nfComp.size():" << fComp.size() << std::endl; //to determine number of components per space
	std::cout << "\nfEle.size(): " << fEle.size() << std::endl;
	std::cout "\nspaceComp3.size(): " << spaceComp3.size() << std::endl;

	unsigned int numSpace = spaceComp3.size();
	std::cout << "numSpace: " << numSpace << std::endl;
	
	// initialise containers for element values
	Eigen::VectorXd    xSpace(numSpace), xNewSpace(numSpace), xChangeSpace(numSpace), 
									volumeSpace(numSpace),  dcSpace(numSpace),   dvSpace(numSpace);
	xChangeSpace.setZero();
	

	unsigned int spaceIndexI = 0;
	for (auto& k : spaceComp3)
	{
		xSpace(spaceIndexI) = f; //what is f   design value of flat shell = f volfrac?
		volumeSpace(spaceIndexI) = 0;
		for (auto& i : k.second)
		{
			for (auto& j : i.second) j->updateDensity(xSpace(spaceIndexI), penal);
			volumeSpace(spaceIndexI) += j->getVolume();
		}
		++spaceIndexI;
	}
	
	totVolume = spaceVolume;
	std::cout << "Total Volume: " << totVolume << std::endl;

	// initialise iteration
	double change = 1;
	int loop = 0;

	double loopStart = clock(), iterationStart, timeEnd = 0.0;

	// start iteration
	while (change > tolerance)
	{
		iterationStart = clock();
		if (loop%20 == 0)
		{
			out << std::endl
					<< std::setw(5)  << std::left << "loop"
					<< std::setw(15) << std::left << "Objective"
					<< std::setw(15) << std::left << "Volume"
					<< std::setw(15) << std::left << "Change"
					<< std::setw(10) << std::left << "Time" << std::endl;
		}

		++loop;
		cF = cB = cT = 0;

		// FEA
		mFEA->generateGSM();
		mFEA->solve("SimplicialLDLT");

		double volume = 0;
		if (spaceComp3.size() > 0)
		{
			ObjectiveAndSensitivity(spaceComp3,cSpace,xSpace,dcSpace,dvSpace,penal);
			OptimalityCritUpdate(0,1e9,xMove,spaceVolume,f,volumeSpace,xSpace,xNewSpace,dvSpace,dcSpace);
			
			unsigned int spacendexI = 0;
			for (auto& k : spaceComp3) 
			{
				for (auto& i : k.second)
				{
					for (auto& j : i.second) j->updateDensity(xNewF(spacendexI), penal);
					volumeSpace(spaceIndexI) += j->getVolume();
				}
				++spaceIndexI;
			}
			xChangeSpace = xNewSpace - xSpace;
			volume += (volumeSpace * xNewSpace.transpose()).trace();
		}
		

		// update change
		change = 0;
		if (spaceComp3.size() > 0)
		{
			change = std::max(change, xChangeSpace.cwiseAbs().maxCoeff()); //whichever is bigger, change or xChange
		}

		timeEnd = clock();
		out << std::setw(5)  << std::left << loop
				<< std::setw(15) << std::left << cF + cB + cT
				<< std::setw(15) << std::left << volume
				<< std::setw(15) << std::left << change
				<< std::setw(10) << std::left << (timeEnd - iterationStart)/CLOCKS_PER_SEC << std::endl;
		//old xF, prints text of old xF 
		/*std::cout << "print text of old xF" << std::endl;
		for (int i = 0; i < xF.size(); ++i) {
					std::cout << xF(i) << " ";}*/
		//added per Eli suggesstion, new xF
		//std::cout << "print text of new xF" << std::endl;
		//for (int i = 0; i < xNewF.size(); ++i) {
					//std::cout << xNewF(i) << " ";
		// //end
		xSpace = xNewSpace;

	} // end of iteration
	
	std::cout << "Topology optimisation successfully finished after: "
			<< (timeEnd - loopStart)/CLOCKS_PER_SEC << " seconds."
			<< std::endl << std::endl;
}
//END of top opt

namespace topology_optimization { namespace testspace_simp {
	
	
void ObjectiveAndSensitivity(
		 const std::map<std::vector<bso::spatial_design::conformal::cf_space>, std::map<component::geometry*, std::vector<element::element*>>& elePerCompPerSpace,
		 double& c, const Eigen::VectorXd& x, Eigen::VectorXd& dc, Eigen::VectorXd& dv,
		 const double& penal)
{
	// objective function and sensitivity analysis (retrieve data from FEA)
	unsigned int spaceIndexI = 0;
	for (const auto& k : elePerCompPerSpace)
	{
		dc(spaceIndexI) =  0; 
		dv(spaceIndexI) =  0;
		for (const auto& i : k.second)
		{ 
			unsigned int spaceIndexI = 0;
			for (auto& j : i.second)
			{
				j->updateDensity(x(spaceIndexI), penal);
				c 						 += j->getTotalEnergy();
				dc(spaceIndexI) += j->getEnergySensitivity(penal); 
				dv(spaceIndexI) += j->getVolume();
			}
		}
		++spaceIndexI;
	}

	dc = (dc * x.transpose()).diagonal();
}

void OptimalityCritUpdate(double l1, double l2, const double& xMove, 
		 const double& totalVolume, const double& f, Eigen::VectorXd& volume,
		 Eigen::VectorXd& x, Eigen::VectorXd& xNew, const Eigen::VectorXd& dv,
		 const Eigen::VectorXd& dc)
{
	// optimality criteria update of design variables and physical densities
	double lmid, upper, lower;
	while (((l2-l1)/(l1+l2))>1e-3)
	{
		lmid = (l1+l2)/2.0;

		for (unsigned int i = 0; i < x.size(); i++)
		{
			xNew(i) = x(i) * (std::sqrt(-dc(i)/(lmid*dv(i))));
			upper = std::min(1.0, (x(i) + xMove));
			lower = std::max(0.0, (x(i) - xMove));

			if (xNew(i) > upper)
			{
				xNew(i) = upper;
			}
			else if (xNew(i) < lower)
			{
				xNew(i) = lower;
			}
		}

		((volume * xNew.transpose()).trace() > f * totalVolume) ? l1 = lmid : l2 = lmid;
	}
}

} // namespace comp_simp
} // namespace topology_optimization
} // namespace structural_design
} // bso

#endif // SD_TOPOPT_COMPONENT_WISE_SIMP_CPP