#ifndef SD_TOPOPT_SPACE_WISE_SIMP2_CPP
#define SD_TOPOPT_SPACE_WISE_SIMP2_CPP

namespace bso { namespace structural_design { namespace topology_optimization {

class TEST2_SIMP;

namespace test2_simp {
void ObjectiveAndSensitivity(const std::map<bso::spatial_design::conformal::cf_space*, std::vector<element::element*>>& elePerSpace,
		 double& c, const Eigen::VectorXd& x, Eigen::VectorXd& dc, Eigen::VectorXd& dv,
		 const double& penal);
void OptimalityCritUpdate(double l1, double l2, const double& xMove, 
		 const double& totalVolume, const double& f, Eigen::VectorXd& volume,
		 Eigen::VectorXd& x, Eigen::VectorXd& xNew, const Eigen::VectorXd& dv,
		 const Eigen::VectorXd& dc);

} // namespace test2_simp
} // namespace topology_optimization

template <>
void sd_model::topologyOptimization<topology_optimization::TEST2_SIMP>(
			const double& f, const double& penal, const double& xMove,
			const double& tolerance)
{
	using namespace topology_optimization::test2_simp;
	std::ostream out(mTopOptStreamBuffer);
	std::map<component::geometry*, std::vector<element::element*>> fComp, bComp, tComp;
	double fVolume = 0, bVolume= 0, tVolume = 0, totVolume = 0; // initialised at 0, before each element volumes are added
	double cS, cB, cT; // sum of all the elements compliances (objective values)
	
	/*compSpace*/std::map<component::geometry*, std::vector<bso::spatial_design::conformal::cf_space>> compSpace;
	/*spaceComp*/std::map<std::vector<bso::spatial_design::conformal::cf_space>, component::geometry*> spaceComp;
	std::map<std::vector<bso::spatial_design::conformal::cf_space>, std::map<component::geometry*, std::vector<element::element*>>> spaceComp3;
	std::map<bso::spatial_design::conformal::cf_space*, std::vector<element::element*>> spaceEle;


	std::cout << "Running TEST2_SIMP: " << std::endl;
	
	std::vector<element::element*> fEle, bEle, tEle; 
	std::map<int, bso::spatial_design::conformal::cf_space*> spaceIDMap;
	int numQuad = 0;
	for (auto& i : mGeometries)
	{
		compSpace.clear();
		if(i->isQuadrilateral())
 		{
			++numQuad;
			//rectangles can be connected to one or two surfaces, which can be connected to one or two spaces
 			//std::cout << "\ni->getCfRectanglePtr() is rectangle: " << *(i->getCfRectanglePtr()) << std::endl;
 			for(const auto k: (i->getCfRectanglePtr())->cfSurfaces())
 			{
 				std::cout << "surface: " << *k << std::endl;
 				std::cout << "connected to the following space(s): " << std::endl;
 				for(const auto space: k->cfSpaces())
 				{
 					std::cout << "space: " << *space << std::endl; //gives the dimensions of the space
					std::cout << "space: " << space->getSpaceID()<< "\n" << std::endl; //gives space ID
					spaceIDMap[space->getSpaceID()] = space; //list of total spaces, cant have duplicate keys, so no repetition of spaces
					//wont work if more spaces are created from the conformal process

					if (spaceEle.find(space) == spaceEle.end())
					{
						spaceEle[space] = std::vector<element::element*>();
					}

					for (auto& j : i->getElements()) 
					{
						if (!j->isActiveInCompliance()) continue;
						j->updateDensity(f, penal);
						if (j->isFlatShell())
						{
							spaceEle[space].push_back(j);
							fVolume += j->getVolume();
						}
					}
 				}
 			} 
 		}
	}

	std::cout << "num of quad geometries: " << numQuad << std::endl;
	std::cout << "\ncompSpace.size(): " << compSpace.size() << "\n" << std::endl;
	std::cout << "cfSpace size: " << spaceIDMap.size() << std::endl;
	

	unsigned int numSpace = spaceEle.size();
	std::cout << "spaceEle.size() = " << spaceEle.size() << std::endl;
	
	// initialise containers for element values
	Eigen::VectorXd xS(numSpace),   xNewS(numSpace),    xChangeS(numSpace), 
									volumeS(numSpace),  dcS(numSpace), dvS(numSpace);
	xChangeS.setZero();
	

	//change values to iterate over each space, change for space values
	unsigned int compIndexI = 0;
	for (auto& i : spaceEle)
	{
		xS(compIndexI) = f;
		volumeS(compIndexI) = 0;
		for (auto& j : i.second) volumeS(compIndexI) += j->getVolume();
		++compIndexI;
	}
	
	totVolume = fVolume+bVolume+tVolume;
	out << "Total Volume: " << totVolume << std::endl;
	
	double change = 1;
	int loop = 0;

	double loopStart = clock(), iterationStart, timeEnd = 0.0;

	// start iteration
	while (change > tolerance)
	{
		iterationStart = clock();
		if (loop%20 == 0)
		{
			out << std::endl
					<< std::setw(5)  << std::left << "loop"
					<< std::setw(15) << std::left << "Objective"
					<< std::setw(15) << std::left << "Volume"
					<< std::setw(15) << std::left << "Change"
					<< std::setw(10) << std::left << "Time" << std::endl;
		}

		++loop;
		cS = 0;

		// FEA
		mFEA->generateGSM();
		mFEA->solve("SimplicialLDLT");

		double volume = 0;
		if (spaceEle.size() > 0)
		{
			ObjectiveAndSensitivity(spaceEle,cS,xS,dcS,dvS,penal);
			OptimalityCritUpdate(0,1e9,xMove,fVolume,f,volumeS,xS,xNewS,dvS,dcS);
			
			unsigned int compIndexI = 0;
			for (auto& i : spaceEle)
			{
				for (auto& j : i.second) j->updateDensity(xNewS(compIndexI), penal);
				++compIndexI;
			}
			xChangeS = xNewS - xS;
			volume += (volumeS * xNewS.transpose()).trace();
		}

		// update change
		change = 0;
		if (spaceEle.size() > 0)
		{
			change = std::max(change, xChangeS.cwiseAbs().maxCoeff());
		}

		timeEnd = clock();
		out << std::setw(5)  << std::left << loop
				<< std::setw(15) << std::left << cS 
				<< std::setw(15) << std::left << volume
				<< std::setw(15) << std::left << change
				<< std::setw(10) << std::left << (timeEnd - iterationStart)/CLOCKS_PER_SEC << std::endl;

		xS = xNewS;
	} // end of iteration

	out << "Topology optimisation successfully finished after: "
			<< (timeEnd - loopStart)/CLOCKS_PER_SEC << " seconds."
			<< std::endl << std::endl;
}

namespace topology_optimization { namespace test2_simp {
	
	
void ObjectiveAndSensitivity(const std::map<bso::spatial_design::conformal::cf_space*, std::vector<element::element*>>& elePerSpace,
		 double& c, const Eigen::VectorXd& x, Eigen::VectorXd& dc, Eigen::VectorXd& dv,
		 const double& penal)
{
	// objective function and sensitivity analysis (retrieve data from FEA)
	unsigned int compIndexI = 0;
	for (const auto& i : elePerSpace) //i is each space
	{
		dc(compIndexI) =  0; 
		dv(compIndexI) =  0;
		for (const auto& j : i.second) //j is each element belonging to that space
		{
			c 						 += j->getTotalEnergy();
			dc(compIndexI) += j->getEnergySensitivity(penal); 
			dv(compIndexI) += j->getVolume();
		}
		++compIndexI;
	}

	dc = (dc * x.transpose()).diagonal();
}

void OptimalityCritUpdate(double l1, double l2, const double& xMove, 
		 const double& totalVolume, const double& f, Eigen::VectorXd& volume,
		 Eigen::VectorXd& x, Eigen::VectorXd& xNew, const Eigen::VectorXd& dv,
		 const Eigen::VectorXd& dc)
{
	// optimality criteria update of design variables and physical densities
	double lmid, upper, lower;
	while (((l2-l1)/(l1+l2))>1e-3)
	{
		lmid = (l1+l2)/2.0;

		for (unsigned int i = 0; i < x.size(); i++)
		{
			xNew(i) = x(i) * (std::sqrt(-dc(i)/(lmid*dv(i))));
			upper = std::min(1.0, (x(i) + xMove));
			lower = std::max(0.0, (x(i) - xMove));

			if (xNew(i) > upper)
			{
				xNew(i) = upper;
			}
			else if (xNew(i) < lower)
			{
				xNew(i) = lower;
			}
		}

		((volume * xNew.transpose()).trace() > f * totalVolume) ? l1 = lmid : l2 = lmid;
		//basically an if else statement
		//if the volume of the new design times the new design value is greater than the volume fraction times the total volume
		//then set l1 to lmid, else set l2 to lmid
	}
}

} // namespace test_simp
} // namespace topology_optimization
} // namespace structural_design
} // bso

#endif // SD_TOPOPT_SPACE_WISE_SIMP2_CPP