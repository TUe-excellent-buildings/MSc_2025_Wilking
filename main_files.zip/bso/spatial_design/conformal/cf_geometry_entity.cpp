#ifndef CF_GEOMETRY_ENTITY_CPP
#define CF_GEOMETRY_ENTITY_CPP

namespace bso { namespace spatial_design { namespace conformal {


} // conformal
} // spatial_design
} // bso

#endif // CF_GEOMETRY_ENTITY_CPP