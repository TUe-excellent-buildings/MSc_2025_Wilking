#ifndef CF_BUILDING_ENTITY_CPP
#define CF_BUILDING_ENTITY_CPP

namespace bso { namespace spatial_design { namespace conformal {

} // conformal
} // spatial_design
} // bso

#endif // CF_BUILDING_ENTITY_CPP